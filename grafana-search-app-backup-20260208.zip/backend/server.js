const express = require('express');
const axios = require('axios');
const cors = require('cors');
const { OAuth2Client } = require('google-auth-library');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;
const CLIENT_ID = "330724176418-0t8l0j37vrguuvt0pjearnstnajnlfj7.apps.googleusercontent.com";
const client = new OAuth2Client(CLIENT_ID);

const PROMETHEUS_URL = "http://10.215.33.196:9090";
const GRAFANA_URL = process.env.GRAFANA_URL;
const GRAFANA_API_KEY = process.env.GRAFANA_API_KEY;

// Mapping Jobs to Master Dashboard UIDs
const MASTER_DASHBOARDS = {
  LINUX: "SMC-Linux-Server-Dashboard-IP-L",
  WINDOWS: "feq43ss3cf8cgd",
  SSL: "ssl-expiry-dashboard12",
  SERVICE: "f1ab9adf-d571-4e26-96fc-8559ebc0f54f"
};

app.use(cors());
app.use(express.json());

async function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    console.log('No Authorization header');
    return res.status(401).json({ error: 'No token provided' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const ticket = await client.verifyIdToken({ idToken: token, audience: CLIENT_ID });
    req.user = ticket.getPayload();
    next();
  } catch (error) {
    console.error('Token verification error:', error.message);
    res.status(401).json({ error: 'Invalid token' });
  }
}

app.get('/api/search', verifyToken, async (req, res) => {
  const { ip } = req.query; // This can be an IP or a Domain
  if (!ip) return res.status(400).json({ error: 'Query is required' });

  try {
    const results = [];
    const isIp = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(ip);

    if (isIp) {
      // PROMETHEUS IP SEARCH (Server Monitoring)
      const promQuery = `up{instance=~"${ip}(:.*)?"}`;
      const promUrl = `${PROMETHEUS_URL}/api/v1/query?query=${encodeURIComponent(promQuery)}`;
      const promResponse = await axios.get(promUrl);
      
      if (promResponse.data.data.result.length > 0) {
        for (const metric of promResponse.data.data.result) {
          const { job, instance } = metric.metric;
          let dashboardUid = MASTER_DASHBOARDS.WINDOWS;
          let type = "Windows Server";
          let varName = "instance";

          const lowerJob = job.toLowerCase();
          
          // Classification logic
          if (lowerJob.includes('service')) {
            dashboardUid = MASTER_DASHBOARDS.SERVICE;
            type = "Service";
            varName = "instance";
          } else if (
            lowerJob.includes('linux') || 
            lowerJob.includes('node') || 
            lowerJob.includes('middleware') || 
            lowerJob.includes('mojo') || 
            lowerJob.includes('mkt') ||
            lowerJob.includes('idg') ||
            lowerJob.includes('load-balancer') ||
            lowerJob.includes('lb')
          ) {
            dashboardUid = MASTER_DASHBOARDS.LINUX;
            type = "Linux Server";
            varName = "node";
          } else {
            dashboardUid = MASTER_DASHBOARDS.WINDOWS;
            type = "Windows Server";
            varName = "instance";
          }

          // Mapping UID to ID (Optional but helpful for React keys)
          const ID_MAP = {
            "SMC-Linux-Server-Dashboard-IP-L": 272,
            "feq43ss3cf8cgd": 370,
            "f1ab9adf-d571-4e26-96fc-8559ebc0f54f": 401,
            "ssl-expiry-dashboard12": 480
          };

          results.push({
            id: ID_MAP[dashboardUid] || Math.floor(Math.random() * 10000),
            uid: dashboardUid,
            title: `${job} (${instance})`,
            url: `/d/${dashboardUid}?var-${varName}=${instance}&var-job=${encodeURIComponent(job)}`,
            type: type,
            tags: [job]
          });
        }
      }
    } else if (ip.includes('.')) {
      // PROMETHEUS DOMAIN SEARCH (SSL Expiry)
      const sslQuery = `probe_ssl_earliest_cert_expiry{instance=~".*${ip}.*"}`;
      const sslUrl = `${PROMETHEUS_URL}/api/v1/query?query=${encodeURIComponent(sslQuery)}`;
      const sslResponse = await axios.get(sslUrl);

      if (sslResponse.data.data.result.length > 0) {
        for (const metric of sslResponse.data.data.result) {
          const { instance } = metric.metric;
          // Extract hostname from URL (e.g., https://example.com:8880/path -> example.com)
          let hostname = instance;
          try {
            const urlObj = new URL(instance);
            hostname = urlObj.hostname;
          } catch (e) {
            // Fallback for non-URL formats
            hostname = instance.replace(/^https?:\/\//, '').split(/[:\/]/)[0];
          }

          results.push({
            id: 480,
            uid: MASTER_DASHBOARDS.SSL,
            title: `Domain SSL Certificate Expiry1: ${instance}`,
            url: `/d/${MASTER_DASHBOARDS.SSL}/?var-domain=${hostname}`,
            type: "Domain SSL Certificate Expiry1",
            tags: ["ssl", "expiry"]
          });
        }
      }
    }

    // FALLBACK: Traditional Grafana Search
    if (results.length === 0) {
      const grafanaSearch = await axios.get(`${GRAFANA_URL}/api/search`, {
        params: { query: ip, type: 'dash-db' },
        headers: { Authorization: `Bearer ${GRAFANA_API_KEY}` }
      });
      results.push(...grafanaSearch.data);
    }

    let filteredResults = results.filter(r => r.type !== "Service");

    const uniqueResults = Array.from(new Map(filteredResults.map(item => [item.url, item])).values());
    res.json(uniqueResults);
  } catch (error) {
    console.error('Search failed:', error.message);
    res.status(500).json({ error: 'Failed to search metrics or dashboards' });
  }
});

app.listen(PORT, () => {
  console.log(`Backend server running on port ${PORT}`);
});
