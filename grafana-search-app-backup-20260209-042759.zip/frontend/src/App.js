import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { GoogleLogin, googleLogout } from '@react-oauth/google';
import { jwtDecode } from 'jwt-decode';

function App() {
  const [ip, setIp] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));

  useEffect(() => {
    if (token) {
      try {
        const decoded = jwtDecode(token);
        setUser(decoded);
      } catch (err) {
        console.error('Invalid token', err);
        handleLogout();
      }
    }
  }, [token]);

  const handleLoginSuccess = (credentialResponse) => {
    const newToken = credentialResponse.credential;
    localStorage.setItem('token', newToken);
    setToken(newToken);
    const decoded = jwtDecode(newToken);
    setUser(decoded);
    setError('');
  };

  const handleLogout = () => {
    googleLogout();
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
    setResults([]);
    setError('');
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!ip) return;

    setLoading(true);
    setError('');
    setResults([]);

    try {
      const response = await axios.get(`/api/search?ip=${ip}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      setResults(response.data);
      if (response.data.length === 0) {
        setError('No dashboards found for this IP.');
      }
    } catch (err) {
      console.error('Search error:', err);
      if (err.response && err.response.status === 401) {
        setError('Session expired. Please login again.');
        handleLogout();
      } else {
        setError('Failed to fetch dashboards. Please check your backend and Grafana configuration.');
      }
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-6 text-center">
            <div className="card shadow border-0 p-5">
              <h2 className="mb-4">Grafana Search Login</h2>
              <p className="text-muted mb-4">Please sign in with your Google account to access the search tool.</p>
              <div className="d-flex justify-content-center">
                <GoogleLogin
                  onSuccess={handleLoginSuccess}
                  onError={() => {
                    setError('Login Failed');
                  }}
                />
              </div>
              {error && <div className="alert alert-danger mt-3">{error}</div>}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-8">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <div className="d-flex align-items-center">
               <img src={user.picture} alt={user.name} className="rounded-circle me-2" style={{width: '40px'}} />
               <div>
                 <strong>{user.name}</strong><br/>
                 <small className="text-muted">{user.email}</small>
               </div>
            </div>
            <button className="btn btn-outline-danger btn-sm" onClick={handleLogout}>Logout</button>
          </div>
          
          <div className="card shadow border-0">
            <div className="card-body p-5">
              <h2 className="text-center mb-4">Grafana Dashboard Search</h2>
              <form onSubmit={handleSearch} className="mb-4">
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control form-control-lg"
                    placeholder="Enter IP Address (e.g., 192.168.1.1)"
                    value={ip}
                    onChange={(e) => setIp(e.target.value)}
                  />
                  <button className="btn btn-primary btn-lg" type="submit" disabled={loading}>
                    {loading ? 'Searching...' : 'Search'}
                  </button>
                </div>
              </form>

              {error && <div className="alert alert-warning text-center">{error}</div>}

              <div className="list-group">
                {results.map((dash) => (
                  <a
                    key={dash.id}
                    href={`${process.env.REACT_APP_GRAFANA_BROWSER_URL || 'http://localhost:3000'}${dash.url}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="list-group-item list-group-item-action d-flex justify-content-between align-items-center p-3 mb-2 rounded border shadow-sm"
                  >
                    <div>
                      <h5 className="mb-1">{dash.title}</h5>
                      <small className="text-muted">Type: {dash.type} | Tags: {dash.tags.join(', ') || 'None'}</small>
                    </div>
                    <span className="badge bg-primary rounded-pill">View</span>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;